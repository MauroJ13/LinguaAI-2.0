import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { linguaApi } from './server/vite-plugin.mjs';

export default defineConfig({
  // relative asset paths, so the built app also works from a sub-folder (e.g. GitHub Pages)
  base: './',
  plugins: [react(), linguaApi()],
  server: { port: 5173, open: false },
});
